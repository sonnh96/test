=== Plugin Name ===
Contributors: (this should be a list of wordpress.org userid's)
Donate link: thikshare.com
Tags: easy call now, call now button, big call button, call icon, call ring button, attractive call button
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Show attractive call button on website with ring ring animation

== Installation ==


1. Upload `easy-callnow.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to Setting -> Easy Call Now and put your number to begin

== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 1.0 =
* first version - minimal version
= 1.1 =
* add color field, position options
= 1.2 =
* Fix icon phone display
