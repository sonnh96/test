(function( $ ) {
	'use strict';

	 jQuery(document).ready(function(){
	 	jQuery('.color-field').wpColorPicker();
	 });
})( jQuery );
