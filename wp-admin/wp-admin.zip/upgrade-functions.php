<?php
/**
 * WordPress Upgrade Functions. Old file, must not be used. Include
 * wp-admin/includes/upgrade.php instead.
 *
 * @deprecated 2.5.0
 * @package WordPress
 * @subpackage Administration
 */

_deprecated_file( basename(__FILE__), '2.5.0', 'wp-admin/includes/upgrade.php' );
require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
